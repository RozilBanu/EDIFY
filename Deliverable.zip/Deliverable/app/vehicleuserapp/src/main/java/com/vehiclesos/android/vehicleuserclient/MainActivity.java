package com.vehiclesos.android.vehicleuserclient;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.vehiclesos.communication.AppConstants;
import com.vehiclesos.communication.ServerContext;
import com.vehiclesos.communication.cachedb.CacheDB;
import com.vehiclesos.communication.message.MessageRequest;
import com.vehiclesos.communication.message.MessageResponse;
import com.vehiclesos.communication.message.MessageResponseListener;
import com.vehiclesos.communication.message.MessageSender;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements MessageResponseListener {

    private static final String HOST = "192.168.1.4";
    private static final String PORT="8080";
    private static final String PATH="/VehicleSOS/client/vehicleuser";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /* Persisting the data for server connectivity*/
        CacheDB.getInstance().addString(this, AppConstants.SERVER_NAME,"192.168.1.4");
        CacheDB.getInstance().addString(this,AppConstants.SERVER_PORT,"8080");
        CacheDB.getInstance().addString(this,AppConstants.CLIENT_SERVLET,"/VehicleSOS/client/vehicleuser");
        setContentView(com.vehiclesos.communication.R.layout.activity_main);

        ServerContext serverContext=new ServerContext();
        /* Create a message request object for sending a message */
        MessageRequest messageRequest=new MessageRequest();
        messageRequest.setRequestType("Login");
        messageRequest.setRequestData(new JSONObject());
        messageRequest.setDeviceID("4565765756g");
        messageRequest.setDevicePlatform("Android");
        new MessageSender(this) //Context
                .setListener(this) //Listener object
                .setPostUrl(serverContext.getClientCommunicationUri(this).toString()) // For setting the url when the data is to be posted
                .setMessageRequest(messageRequest) // set the message request object
                .send(); // send the data
    }

    @Override
    public void onMessageSend(MessageRequest request) {
        Log.i(AppConstants.LOG_TAG,"Message sending initated");
    }

    @Override
    public void onMessageSuccess(MessageRequest request, MessageResponse response) {
        Log.i(AppConstants.LOG_TAG,"Message sending success");
        Log.i(AppConstants.LOG_TAG,"Request : "+request.toString());
        Log.i(AppConstants.LOG_TAG,"Response : "+response.toString());
    }

    @Override
    public void onMessageFailed(MessageRequest request, MessageResponse response) {
        Log.i(AppConstants.LOG_TAG,"Message sending failed");
        Log.i(AppConstants.LOG_TAG,"Request : "+request.toString());
        Log.i(AppConstants.LOG_TAG,"Response : "+response.toString());
    }

    @Override
    public void onMessageHandleError(MessageRequest request, MessageResponse response, String errorMessage, int errorCode) {
        Log.i(AppConstants.LOG_TAG,"Message sending error");
        Log.i(AppConstants.LOG_TAG,"Request : "+request.toString());
        Log.i(AppConstants.LOG_TAG,"Response : "+response.toString());
        Log.i(AppConstants.LOG_TAG,"Error Code : "+errorCode+", ErrorMessage : "+errorMessage);
    }
}

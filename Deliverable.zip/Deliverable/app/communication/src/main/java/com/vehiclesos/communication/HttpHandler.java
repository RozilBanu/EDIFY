package com.vehiclesos.communication;

import android.util.Log;

import com.squareup.okhttp.ConnectionPool;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;
import com.squareup.okhttp.ResponseBody;

import org.json.JSONObject;

import java.io.IOException;
import java.net.Proxy;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

/**
 * Created by sarangan-3096 on 25-Mar-17.
 */
public class HttpHandler {

    public static final int ERROR_UNKNOWN = -1;
    public static final int ERROR_NONE = 0;
    /**
     * Host address cannot be resolved. Wrong host address, host cannot be resolved or network maybe disconnected
     */
    public static final int ERROR_UNKNOWN_HOST = 1;
    /**
     * Network disconnected or this address cannot be reached over the current network
     */
    public static final int ERROR_NETWORK_UNREACHABLE = 2;
    /**
     * Connection has timed out, the connecting port maybe blocked
     */
    public static final int ERROR_SOCKET_TIMEOUT = 3;
    /*
     * Connection refused, maybe connecting at wrong port
     */
    public static final int ERROR_CONNECTION_REFUSED = 4;

    public static final int ERROR_MALFORMED_URL=23;

    public static final int HTTP_STATUS_SUCCESS = 200;
    public static final int HTTP_STATUS_FAILURE = 1;

    private static final int BUFFER_SIZE = 4096;
    private static final MediaType JSON  = MediaType.parse("application/json; charset=utf-8");		//NO I18N
    private static final MediaType TEXT  = MediaType.parse("text/html; charset=utf-8");
    private static final MediaType FILE_ZIP = MediaType.parse("application/zip"); //NO I18N
    private OkHttpClient client ;

    /**
     * Default Constructor
     */
    public HttpHandler(){
        client = new OkHttpClient();
        client.setConnectTimeout(20000L, TimeUnit.MILLISECONDS);		//Connection timeout is time elapse making server first connection
        client.setReadTimeout(20000L, TimeUnit.MILLISECONDS);			//Read timeout is time elapse for socket read
        client.setWriteTimeout(20000L, TimeUnit.MILLISECONDS);			//Write timeout is time elapse for socket write
        client.setConnectionPool(new ConnectionPool(3, 4000L));			//Max 2 idle connection for 4 seconds
    }

    public HttpHandler(SSLContext sslContext, HostnameVerifier hostNameVerifier) {
        client = new OkHttpClient();
        client.setSslSocketFactory(sslContext.getSocketFactory());
        client.setHostnameVerifier(hostNameVerifier);
        client.setConnectTimeout(20000L, TimeUnit.MILLISECONDS);		//Connection timeout is time elapse making server first connection
        client.setReadTimeout(20000L, TimeUnit.MILLISECONDS);			//Read timeout is time elapse for socket read
        client.setWriteTimeout(20000L, TimeUnit.MILLISECONDS);			//Write timeout is time elapse for socket write
        client.setConnectionPool(new ConnectionPool(3, 4000L));			//Max 2 idle connection for 4 seconds
    }

    public void setProxy(Proxy proxy) {
        client.setProxy(proxy);
    }

    public void clearProxy() {
        client.setProxy(Proxy.NO_PROXY);
    }

    /**
     * Used to communicate with agent to server
     * @param httpUrl
     * @param dataToSend
     * @return
     */
    protected HttpResponse communicateWithMDMServer(String httpUrl, String dataToSend) {
        HttpResponse httpResponse=new HttpResponse();
        HttpStatus httpStatus=new HttpStatus();
        RequestBody requestBody = RequestBody.create(JSON, dataToSend);
        Request request = prepareRequest(httpUrl, requestBody, true);
        Log.i(AppConstants.LOG_TAG,"Posting URL : "+httpUrl);
        Log.i(AppConstants.LOG_TAG,"Data Posted : "+dataToSend);
        try {
            Response response = client.newCall(request).execute();
            if(response.isSuccessful()){
                httpStatus.setHttpStatus(HTTP_STATUS_SUCCESS);
                ResponseBody responseBody = response.body();
                httpResponse.setResponseData(responseBody.string());
                httpResponse.setHttpStatus(httpStatus);
                responseBody.close();
            }
            else {
                httpStatus.setHttpStatus(HTTP_STATUS_FAILURE);
                httpResponse.setHttpStatus(httpStatus);
                Log.i(AppConstants.LOG_TAG, "Failed to connect. Error Code - "+response.code());
            }
        } catch (IOException ex) {
            Log.i(AppConstants.LOG_TAG,"Exception occurred while requesting "+ex.getMessage());
            httpResponse.setHttpStatus(prepareErrorStatus(httpStatus, ex));
        }
        return httpResponse;
    }

    /**
     * API to prepare @com.squareup.okhttp.Request Object for the given input
     * @param url
     * @param requestBody
     * @param keepAlive
     * @return
     */
    private Request prepareRequest(String url, RequestBody requestBody, boolean keepAlive){
        Request.Builder requestBuilder = new Request.Builder();
        requestBuilder.url(url);
        requestBuilder.header("Connection", keepAlive?"keep-alive":"close");							//NO I18N
        if(requestBody != null){
            requestBuilder.post(requestBody);
        }

        return requestBuilder.build();
    }

    /**
     * To Post any data to server
     * @param httpURL
     * @param cmdObject
     * @return
     * @throws Exception
     *
     * @hide
     */
    public HttpResponse postRequest(String httpURL, JSONObject cmdObject) throws Exception {
        return communicateWithMDMServer(httpURL, cmdObject.toString());
    }


//    /**
//     * To download an file
//     * @param downloadUrl relative download url to download the file [server name and port is excluded ]
//     * @param fileLocation complete destination path to save the file
//     * @param context
//     * @return either HTTP_STATUS_FAILURE or HTTP_STATUS_SUCCESS
//     */
//    public HttpStatus downloadFiles(String downloadUrl, String fileLocation,Context context) {
//        HttpStatus status = new HttpStatus(HTTP_STATUS_FAILURE, HttpStatus.ERROR_DOWNLOAD_FAILED);
//        try {
//            if(AgentUtil.getInstance().createDirectory(new File(fileLocation).getParentFile())){
//                downloadUrl = downloadUrl.replaceAll("\\\\", "/");
//                downloadUrl = getFileDownloadURL(context, downloadUrl);
//                FileOutputStream outStream = new FileOutputStream(fileLocation);
//                status =  downloadFile(downloadUrl, outStream);
//            }
//            else{
//                MDMLogger.error("Unable to create a directory specifed to save the downloaded file");
//                status.setErrorCode(HttpStatus.ERROR_DOWNLOAD_FAILED_DIRECTORY);
//            }
//        } catch (FileNotFoundException e) {
//            MDMLogger.error("Failed to open File stream to save the downloaded file ", e);
//            status.setErrorCode(HttpStatus.ERROR_DOWNLOAD_FAILED_FILE_NOT_FOUND);
//        } catch(UnsupportedEncodingException e) {
//            MDMLogger.error("Invalid url format "+e.toString()+" Cause: "+e.getCause());
//            prepareErrorStatus(status, e);
//        } catch (IOException e) {
//            MDMLogger.error("Failed to download file: "+e.toString()+" Cause: "+e.getCause());
//        }
//        return status;
//    }
//
//    /**
//     * To download an file for App installation in SAFE
//     * @param downloadUrl relative download url to download the file [server name and port is excluded ]
//     * @param fileLocation complete destination path to save the file
//     * @param context
//     * @return either HTTP_STATUS_FAILURE or HTTP_STATUS_SUCCESS
//     */
//    public HttpStatus downloadAPKFiles(String downloadUrl, String destFile,Context context) {
//        HttpStatus status = new HttpStatus(HTTPHandler.HTTP_STATUS_FAILURE, HttpStatus.ERROR_DOWNLOAD_FAILED);
//        try {
//            downloadUrl = downloadUrl.replaceAll("\\\\", "/");
//            downloadUrl = getFileDownloadURL(context, downloadUrl);
//            deleteExisting(AgentUtil.getInstance().getAPKDownloadDir(context)+File.separator+downloadUrl);
//            FileOutputStream outStream = context.openFileOutput(destFile, 32769);
//            status = downloadFile(downloadUrl, outStream);
//        } catch (FileNotFoundException e) {
//            MDMLogger.error("Failed to open File stream to save the downloaded file "+e.getMessage()+" , "+e.getCause());
//            status.setErrorCode(HttpStatus.ERROR_DOWNLOAD_FAILED_FILE_NOT_FOUND);
//        } catch(UnsupportedEncodingException e) {
//            MDMLogger.error("Invalid url format "+e.toString()+" Cause: "+e.getCause());
//            prepareErrorStatus(status, e);
//        } catch (Exception e) {
//            MDMLogger.error("Failed to download APK file: "+e.toString()+" Cause: "+e.getCause());
//            prepareErrorStatus(status, e);
//        }
//        return status;
//    }
//
//    /**
//     * This method does not add server path to the given URL, treats it as complete URL to download the file.
//     * @param completeURL - complete URL to download the file.
//     * @param localFilePath
//     * @return
//     */
//    public HttpStatus downloadFileFromURL(String completeURL, String localFilePath) {
//        HttpStatus status = new HttpStatus(HTTP_STATUS_FAILURE, HttpStatus.ERROR_DOWNLOAD_FAILED);
//        try {
//            //File destFile = new File(localFilePath);
//            //destFile.mkdirs();
//            FileOutputStream outStream = new FileOutputStream(localFilePath);
//            status =  downloadFile(completeURL, outStream);
//        } catch (FileNotFoundException e) {
//            MDMLogger.error("Failed to open File stream to save the downloaded file ", e);
//            status.setErrorCode(HttpStatus.ERROR_DOWNLOAD_FAILED_FILE_NOT_FOUND);
//        } catch (IOException e) {
//            MDMLogger.error("Failed to download file: "+e.toString()+" Cause: "+e.getCause());
//        }
//        return status;
//
//    }
//
//
//    /**
//     * Downloads a file from a URL
//     * @param fileURL HTTP URL of the file to be downloaded
//     * @param fileSaveLocation path of the directory to save the file
//     * @throws IOException
//     */
//    private HttpStatus downloadFile(String fileURL, FileOutputStream outputStream) throws IOException {
//        HttpStatus status = new HttpStatus(HTTP_STATUS_FAILURE, HttpStatus.ERROR_DOWNLOAD_FAILED);
//        String url = AgentUtil.getInstance().encodeUrl(fileURL);
//        MDMLogger.info("OKHttpHandler downloadFile(), encoded URL = "+url);
//        Request request = prepareRequest(url, null, true);		//set keepalive as false since this is not continuous connection
//        try {
//            Response response = client.newCall(request).execute();
//            if(response.isSuccessful()){
//                ResponseBody responseBody = response.body();
//
//                InputStream inputStream = responseBody.byteStream();
//
//                int bytesRead = -1;
//                byte[] buffer = new byte[BUFFER_SIZE];
//                while ((bytesRead = inputStream.read(buffer)) != -1) {
//                    outputStream.write(buffer, 0, bytesRead);
//                }
//                status.setStatus(HTTP_STATUS_SUCCESS);
//                status.setErrorCode(HttpStatus.ERROR_NONE);
//                inputStream.close();
//                responseBody.close();
//                MDMLogger.info("File downloaded");
//            }
//            else{
//                MDMLogger.info("No file to download. Server replied HTTP code: " + response);
//            }
//        } catch (IOException e) {
//            MDMLogger.error("Failed to send the status to the server : IOException "+ e.toString()+" Cause: "+e.getCause());
//            prepareErrorStatus(status, e);
//        } finally{
//            outputStream.close();
//        }
//        return status;
//    }
//
//    @Override
//    public HttpStatus uploadFile(Context context, String relativeURL, File fileToUpload) {
//        HttpStatus status = new HttpStatus(HTTP_STATUS_FAILURE);
//        try {
//            RequestBody requestBody = RequestBody.create(FILE_ZIP, fileToUpload);
//            MDMLogger.debug("REQUEST created: "+requestBody.toString());
//            String httpURL = AgentUtil.constructServerDetails(context)+relativeURL;
//            Request request = prepareRequest(httpURL, requestBody, false);
//            MDMLogger.info("HTTPHandler: Upload file begins.. URL: "+httpURL);
//            synchronized (client) {
//                Response response = client.newCall(request).execute();
//                if(response.isSuccessful()){
//                    ResponseBody responseBody = response.body();
//                    status.setUrlDataBuffer(responseBody.string());
//                    status.setStatus(HTTP_STATUS_SUCCESS);
//                    responseBody.close();
//                }
//            }
//        } catch (Exception e) {
//            MDMLogger.error("Exception while uploading file to server ", e);
//            prepareErrorStatus(status, e);
//        }
//        return status;
//    }
//
//    private String getFileDownloadURL(Context context, String relURL) throws UnsupportedEncodingException {
//        Uri serverURI=Uri.parse(AgentUtil.constructServerDetails(context)+relURL);
//        Uri.Builder uriBuilder= serverURI.buildUpon();
//        Uri downloadURI=uriBuilder
//                .build();
//        if(AgentUtil.isServerOnDemand(MDMApplication.getContext())) {
//            String scope = MDMAgentParamsTableHandler.getInstance(context).getStringValue( "scope"); //NO I18N
//            String authtoken = MDMAgentParamsTableHandler.getInstance(context).getStringValue( "authtoken"); //NO I18N
//            long customerID = MDMAgentParamsTableHandler.getInstance(context).getLongValue( EnrollmentConstants.CUSTOMER_ID);
//            uriBuilder= downloadURI.buildUpon();
//            downloadURI=uriBuilder
//                    .appendQueryParameter("SCOPE",scope) //NO I18N
//                    .appendQueryParameter("authtoken",authtoken) //NO I18N
//                    .appendQueryParameter("customerId",String.valueOf(customerID)) //NO I18N
//                    .build();
//        }
//        return URLDecoder.decode(downloadURI.toString(),"UTF-8");
//    }


    private HttpStatus prepareErrorStatus(HttpStatus status, Exception e) {
        int errorCode = getErrorCode(e);
        status.setHttpStatus(HTTP_STATUS_FAILURE);
        status.setErrorCode(errorCode);
        return status;
    }

    public static int getErrorCode(Exception e) {
        int errorCode = ERROR_UNKNOWN;
        String eString = e.toString();
        if (eString.contains("UnknownHostException")) { //NO I18N
            errorCode = ERROR_UNKNOWN_HOST;
        }
        else if (eString.contains("SocketTimeoutException")) { //NO I18N
            errorCode = ERROR_SOCKET_TIMEOUT;
        }
        else if (eString.contains("ConnectException") && eString.contains("Network is unreachable")) { //NO I18N
            errorCode = ERROR_NETWORK_UNREACHABLE;
        }
        else if (eString.contains("ConnectException") && eString.contains("Connection refused")) { //NO I18N
            errorCode = ERROR_CONNECTION_REFUSED;
        }
        else if(eString.contains("UnsupportedEncodingException")) {
            errorCode = ERROR_MALFORMED_URL;
        }
        return errorCode;
    }
}

package com.vehiclesos.communication.message;

import android.util.Log;

import com.vehiclesos.communication.AppConstants;

import org.json.JSONObject;

/**
 * Created by sarangan-3096 on 26-Mar-17.
 */
public class MessageRequest {
    private String devicePlatform;
    private String requestType;
    private JSONObject requestData;
    private String deviceID;

    public void setDeviceID(String deviceID) {
        this.deviceID = deviceID;
    }

    public void setRequestData(JSONObject requestData) {
        this.requestData = requestData;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public void setDevicePlatform(String devicePlatform) {
        this.devicePlatform = devicePlatform;
    }

    public JSONObject getRequestData() {
        return requestData;
    }

    public String getDeviceID() {
        return deviceID;
    }

    public String getRequestType() {
        return requestType;
    }

    public String getDevicePlatform() {
        return devicePlatform;
    }

    @Override
    public String toString() {
        JSONObject messageRequest=new JSONObject();
        try {
            messageRequest.put(MessageConstants.DEVICE_ID,getDeviceID());
            messageRequest.put(MessageConstants.DEVICE_PLATFORM,getDevicePlatform());
            messageRequest.put(MessageConstants.MESSAGE_TYPE, getRequestType());
            messageRequest.put(MessageConstants.MESSAGE_REQUEST_DATA, getRequestData());
        }
        catch(Exception ex) {
            Log.e(AppConstants.LOG_TAG,"Exception while dumping the request message",ex);
        }
        return messageRequest.toString();
    }

    public static MessageRequest toMessageRequest(JSONObject jsonRequest) {
        MessageRequest messageRequest=new MessageRequest();
        messageRequest.setDeviceID(jsonRequest.optString(MessageConstants.DEVICE_ID));
        messageRequest.setDevicePlatform(jsonRequest.optString(MessageConstants.DEVICE_PLATFORM));
        messageRequest.setRequestData(jsonRequest.optJSONObject(MessageConstants.MESSAGE_REQUEST_DATA));
        messageRequest.setRequestType(jsonRequest.optString(MessageConstants.MESSAGE_TYPE));
        return messageRequest;
    }
}

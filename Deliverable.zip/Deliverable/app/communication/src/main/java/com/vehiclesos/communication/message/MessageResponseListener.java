package com.vehiclesos.communication.message;

/**
 * Created by sarangan-3096 on 26-Mar-17.
 */
public interface MessageResponseListener {
    /**
     * This is called when the message sending is initiated
     * @param request MessageRequest.
     */
    void onMessageSend(MessageRequest request);

    /**
     * This is called when the message is successfully sent
     * @param request MessageRequest sent
     * @param response MessageResponse obtained from the server
     */
    void onMessageSuccess(MessageRequest request, MessageResponse response);

    /**
     * This is called when the message sending is not successful. This occurs when there is a network connectivity error
     * @param request MessageRequest
     * @param response MessageResponse
     */
    void onMessageFailed(MessageRequest request, MessageResponse response);

    /**
     * This is called when the message sending is successfully when the server replies with status error.
     * @param request MessageRequest sent
     * @param response MessageResponse obtained from the server
     * @param errorMessage Error message from the server.
     * @param errorCode Error code from the server
     */
    void onMessageHandleError(MessageRequest request, MessageResponse response, String errorMessage, int errorCode);
}

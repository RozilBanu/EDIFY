package com.vehiclesos.communication.message;

import android.content.Context;
import android.content.Intent;
import android.os.Messenger;
import android.util.Log;

import com.vehiclesos.communication.AppConstants;
import com.vehiclesos.communication.HttpHandler;
import com.vehiclesos.communication.HttpResponse;

import org.json.JSONObject;

/**
 * Created by sarangan-3096 on 26-Mar-17.
 */
public class MessageSender {
    private Context context;
    private String postUrl;
    private MessageRequest messageRequest;
    private MessageResponseListener listener;
    public MessageSender(Context context) {
        this.context=context;
    }

    /**
     * Send the message to the server by the updating the UI. Listener based message sending
     */
    public void send() {
        if(postUrl==null) {
            throw new IllegalArgumentException("Posting URL is null");
        }
        else if(messageRequest == null) {
            throw new IllegalArgumentException("Invalid message request");
        }
        MessageResponseHandler messageResponseHandler=new MessageResponseHandler();
        if(listener!=null) {
            messageResponseHandler.setMessageResponseListener(listener);
        }
        Messenger messenger=new Messenger(messageResponseHandler);
        Intent intent=new Intent();
        intent.putExtra(MessageSendingService.EXTRA_MESSAGE_ACTION,MessageConstants.ACTION_MESSAGE_SEND);
        intent.putExtra(MessageSendingService.EXTRA_MESSAGE_REQUEST,messageRequest.toString());
        intent.putExtra(MessageSendingService.EXTRA_MESSENGER,messenger);
        intent.putExtra(MessageSendingService.EXTRA_POST_URL, postUrl);
        intent.setClass(context, MessageSendingService.class);
        if(listener!=null) {
            listener.onMessageSend(messageRequest);
        }
        context.startService(intent);
    }

    /**
     * This can message can be used when you are already in some service and you want to just send the message to the server and get
     * the response
     * @return MessageResponse
     */
    public MessageResponse sendWithoutNotifying() {
        HttpHandler httpHandler=new HttpHandler();
        MessageResponse messageResponse=null;
        try {
            HttpResponse response=httpHandler.postRequest(postUrl, new JSONObject(messageRequest.toString()));
            if(response!=null) {
                messageResponse=MessageResponse.toMessageResponse(new JSONObject(response.getResponseData()));
            }
            else {
                messageResponse=new MessageResponse();
            }
            messageResponse.setHttpStatus(response.getHttpStatus());
        }
        catch(Exception ex) {
            Log.e(AppConstants.LOG_TAG,"Exception while sending the data to the server",ex);
        }
        return messageResponse;
    }

    public MessageSender setPostUrl(String postUrl) {
        this.postUrl = postUrl;
        return this;
    }

    public MessageSender setMessageRequest(MessageRequest messageRequest) {
        this.messageRequest = messageRequest;
        return this;
    }

    public MessageSender setListener(MessageResponseListener listener) {
        this.listener = listener;
        return this;
    }
}

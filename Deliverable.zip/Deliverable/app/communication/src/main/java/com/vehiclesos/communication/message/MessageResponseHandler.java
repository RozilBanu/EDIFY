package com.vehiclesos.communication.message;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.vehiclesos.communication.AppConstants;
import com.vehiclesos.communication.HttpHandler;
import com.vehiclesos.communication.HttpStatus;

/**
 * Created by sarangan-3096 on 26-Mar-17.
 */
public class MessageResponseHandler extends Handler {
    private MessageResponseListener listener;
    @Override
    public void handleMessage(Message msg) {
        MessageContainer messageContainer=(MessageContainer) msg.obj;
        MessageRequest messageRequest=messageContainer.getMessageRequest();
        MessageResponse messageResponse=messageContainer.getMessageResponse();
        HttpStatus httpStatus=messageResponse.getHttpStatus();
        Log.i(AppConstants.LOG_TAG,"Http Status : "+httpStatus.toString());
        int httpStatusCode=httpStatus.getHttpStatus();
        if(httpStatusCode == HttpHandler.HTTP_STATUS_SUCCESS) {
            if(messageResponse.getErrorMessage() == null && messageResponse.getErrorCode() == 0) {
                if(listener!=null) {
                    listener.onMessageSuccess(messageRequest, messageResponse);
                }
            }
            else {
                if(listener!=null) {
                    listener.onMessageHandleError(messageRequest,messageResponse,messageResponse.getErrorMessage(), messageResponse.getErrorCode());
                }
            }
        }
        else {
            if(listener!=null) {
                listener.onMessageFailed(messageRequest, messageResponse);
            }
        }

    }

    public void setMessageResponseListener(MessageResponseListener listener) {
        this.listener=listener;
    }
}

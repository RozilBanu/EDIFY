package com.vehiclesos.communication;

/**
 * Created by sarangan-3096 on 26-Mar-17.
 */
public class HttpStatus {

    private int httpStatus;
    private String httpErrorMessage;
    private int errorCode;

    public void setHttpErrorMessage(String httpErrorMessage) {
        this.httpErrorMessage = httpErrorMessage;
    }

    public void setHttpStatus(int httpStatus) {
        this.httpStatus = httpStatus;
    }

    public int getHttpStatus() {
        return httpStatus;
    }

    public String getHttpErrorMessage() {
        return httpErrorMessage;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public int getErrorCode() {
        return errorCode;
    }

    @Override
    public String toString() {
        return "HttpStatus : "+httpStatus+", HttpErrorCode : "+errorCode+", HttpErrorMessage : "+httpErrorMessage;
    }
}

package com.vehiclesos.communication;

/**
 * Created by sarangan-3096 on 26-Mar-17.
 */
public class AppConstants {
    public static final String LOG_TAG="SOSLOG";
    public static final String SERVER_NAME="ServerName";
    public static final String SERVER_PORT="ServerPort";
    public static final String CLIENT_SERVLET="ClientServlet";
}

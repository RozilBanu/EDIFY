package com.vehiclesos.communication.message;

import android.util.Log;

import com.vehiclesos.communication.AppConstants;
import com.vehiclesos.communication.HttpStatus;

import org.json.JSONObject;

/**
 * Created by sarangan-3096 on 26-Mar-17.
 */
public class MessageResponse {
    private String platform;
    private String requestType;
    private JSONObject responseData;
    private String remarks;
    private String deviceID;
    private int errorCode;
    private String errorMessage;
    private String status;
    private HttpStatus httpStatus;

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public void setDeviceID(String deviceID) {
        this.deviceID = deviceID;
    }

    public void setResponseData(JSONObject responseData) {
        this.responseData = responseData;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getRequestType() {
        return requestType;
    }

    public String getRemarks() {
        return remarks;
    }

    public String getDeviceID() {
        return deviceID;
    }

    public JSONObject getResponseData() {
        return responseData;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public String getPlatform() {
        return platform;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    @Override
    public String toString() {
        JSONObject responseJson=new JSONObject();
        try {
            responseJson.put(MessageConstants.DEVICE_PLATFORM, getPlatform());
            responseJson.put(MessageConstants.DEVICE_ID, getDeviceID());
            responseJson.put(MessageConstants.MESSAGE_STATUS, getStatus());
            responseJson.put(MessageConstants.MESSAGE_TYPE, getRequestType());
            responseJson.put(MessageConstants.MESSAGE_RESPONSE_DATA, getResponseData());
            if(getErrorCode()!=0) {
                responseJson.put(MessageConstants.ERROR_MESSAGE,getErrorMessage());
                responseJson.put(MessageConstants.ERROR_CODE,getErrorCode());
            }
        }
        catch(Exception ex) {
            Log.e(AppConstants.LOG_TAG,"Exception while dumping the message response",ex);
        }
        return responseJson.toString();
    }

    public static MessageResponse toMessageResponse(JSONObject jsonResponse) {
        MessageResponse messageResponse=new MessageResponse();
        messageResponse.setPlatform(jsonResponse.optString(MessageConstants.DEVICE_PLATFORM,null));
        messageResponse.setDeviceID(jsonResponse.optString(MessageConstants.DEVICE_ID,null));
        messageResponse.setStatus(jsonResponse.optString(MessageConstants.MESSAGE_STATUS,null));
        if(messageResponse.getStatus()!=null && messageResponse.getStatus().equals(MessageConstants.MESSAGE_STATUS_ERROR)) {
            messageResponse.setErrorMessage(jsonResponse.optString(MessageConstants.ERROR_MESSAGE));
            messageResponse.setErrorCode(jsonResponse.optInt(MessageConstants.ERROR_CODE, MessageConstants.ERROR_CODE_UNKNOWN));
        }
        messageResponse.setPlatform(jsonResponse.optString(MessageConstants.DEVICE_PLATFORM,null));
        messageResponse.setResponseData(jsonResponse.optJSONObject(MessageConstants.MESSAGE_RESPONSE_DATA));
        messageResponse.setRemarks(jsonResponse.optString(MessageConstants.MESSAGE_REMARKS));
        messageResponse.setRequestType(jsonResponse.optString(MessageConstants.MESSAGE_TYPE));
        return messageResponse;
    }
}

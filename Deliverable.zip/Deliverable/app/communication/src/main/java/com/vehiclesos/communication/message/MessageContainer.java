package com.vehiclesos.communication.message;

import com.vehiclesos.communication.HttpStatus;

/**
 * Created by sarangan-3096 on 26-Mar-17.
 */
public class MessageContainer {
    private HttpStatus httpStatus;
    private MessageRequest messageRequest;
    private MessageResponse messageResponse;

    protected void setMessageRequest(MessageRequest messageRequest) {
        this.messageRequest = messageRequest;
    }

    protected void setMessageResponse(MessageResponse messageResponse) {
        this.messageResponse = messageResponse;
    }

    protected MessageRequest getMessageRequest() {
        return messageRequest;
    }

    protected MessageResponse getMessageResponse() {
        return messageResponse;
    }

    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }
}

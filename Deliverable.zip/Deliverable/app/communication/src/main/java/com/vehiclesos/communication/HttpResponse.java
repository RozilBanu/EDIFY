package com.vehiclesos.communication;

/**
 * Created by sarangan-3096 on 25-Mar-17.
 */
public class HttpResponse {
    private HttpStatus httpStatus;
    private String responseData;

    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public void setResponseData(String responseData) {
        this.responseData = responseData;
    }
    public String getResponseData() {
        return responseData;
    }

}

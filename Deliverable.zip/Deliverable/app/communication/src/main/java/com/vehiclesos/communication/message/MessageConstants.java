package com.vehiclesos.communication.message;

/**
 * Created by sarangan-3096 on 26-Mar-17.
 */
public interface MessageConstants {
    String DEVICE_PLATFORM="DevicePlatform";
    String MESSAGE_TYPE="MessageType";
    String MESSAGE_REQUEST_DATA="MessageRequestData";
    String MESSAGE_RESPONSE_DATA="MessageResponseData";
    String DEVICE_ID="DeviceID";
    String MESSAGE_STATUS="Status";
    String MESSAGE_STATUS_ERROR="Error";
    String ERROR_MESSAGE="ErrorMessage";
    String ERROR_CODE="ErrorCode";
    String ERROR_MSG_UNKNOWN="Unknown";
    int ERROR_CODE_UNKNOWN=-100;
    String MESSAGE_STATUS_ACK="Acknowledged";
    String MESSAGE_REMARKS="Remarks";
    int ACTION_MESSAGE_SEND=1;
    interface MessageType{

    }

    interface MessageField {
        String DEVICE_PLATFORM_ANDROID="Android";
    }
}

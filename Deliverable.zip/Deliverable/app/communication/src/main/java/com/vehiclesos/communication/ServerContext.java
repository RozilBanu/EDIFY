package com.vehiclesos.communication;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import com.vehiclesos.communication.cachedb.CacheDB;

/**
 * Created by sarangan-3096 on 26-Mar-17.
 */
public class ServerContext {

    private Uri getServerUri(Context context) {
        String serverName= CacheDB.getInstance().getString(context,AppConstants.SERVER_NAME);
        String portNumber=CacheDB.getInstance().getString(context,AppConstants.SERVER_PORT);
        Uri serverUri=new Uri.Builder()
                        .scheme("http")
                        .encodedAuthority(serverName+":"+portNumber)
                        .build();
        return serverUri;
    }

    public Uri getClientCommunicationUri(Context context) {
        String clientServlet=CacheDB.getInstance().getString(context,AppConstants.CLIENT_SERVLET);
        return getServerUri(context).buildUpon()
                    .path(clientServlet)
                    .build();
    }

}

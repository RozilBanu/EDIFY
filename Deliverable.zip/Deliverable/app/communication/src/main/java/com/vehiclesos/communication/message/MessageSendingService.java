package com.vehiclesos.communication.message;

import android.app.IntentService;
import android.content.Intent;
import android.os.Message;
import android.os.Messenger;
import android.util.Log;

import com.vehiclesos.communication.AppConstants;
import com.vehiclesos.communication.HttpHandler;
import com.vehiclesos.communication.HttpResponse;

import org.json.JSONObject;

/**
 * Created by sarangan-3096 on 26-Mar-17.
 */
public class MessageSendingService extends IntentService {

    public static final String EXTRA_MESSAGE_REQUEST="MessageRequest";
    public static final String EXTRA_MESSENGER="Messenger";
    public static final String EXTRA_MESSAGE_ACTION="MessaeAction";
    public static final String EXTRA_POST_URL="PostURL";

    public MessageSendingService() {
        super("MessageSendingService");
        setIntentRedelivery(true);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        int action=intent.getIntExtra(EXTRA_MESSAGE_ACTION, MessageConstants.ACTION_MESSAGE_SEND);
        switch (action) {
            case MessageConstants.ACTION_MESSAGE_SEND:
                sendMessage(intent);

        }
    }

    private void sendMessage(Intent intent) {
        String messageRequestString=intent.getStringExtra(EXTRA_MESSAGE_REQUEST);
        Messenger messenger=(Messenger)intent.getExtras().get(EXTRA_MESSENGER);
        String postUrl=intent.getStringExtra(EXTRA_POST_URL);
        HttpHandler httpHandler=new HttpHandler();
        try {
            MessageContainer container=new MessageContainer();
            MessageResponse messageResponse=null;
            JSONObject requestJSON=new JSONObject(messageRequestString);
            HttpResponse response=httpHandler.postRequest(postUrl, requestJSON);
            if(response.getResponseData()!=null) {
                JSONObject responseJson=new JSONObject(response.getResponseData());
                messageResponse=MessageResponse.toMessageResponse(responseJson);
            }
            else {
                messageResponse=new MessageResponse();
            }
            messageResponse.setHttpStatus(response.getHttpStatus());
            container.setMessageResponse(messageResponse);
            MessageRequest messageRequest=MessageRequest.toMessageRequest(requestJSON);
            container.setMessageRequest(messageRequest);
            container.setHttpStatus(response.getHttpStatus());
            Message message= Message.obtain();
            message.obj=container;
            messenger.send(message);
        }
        catch(Exception ex) {
            Log.e(AppConstants.LOG_TAG,"Error while parsing the request data to json",ex);
        }
    }
}

package com.vehiclesos.communication.cachedb;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.vehiclesos.communication.AppConstants;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by sarangan-3096 on 26-Mar-17.
 */
public class CacheDB {
    private static CacheDB cacheDB;
    private static final String CACHE_DB_NAME="cachedb";

    private CacheDB() {

    }
    public static CacheDB getInstance() {
        if(cacheDB == null) {
            cacheDB=new CacheDB();
        }
        return cacheDB;
    }

    private void addValue(Context context, String key, String value) {
        SharedPreferences pref=context.getSharedPreferences(CACHE_DB_NAME,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=pref.edit();
        editor.putString(key,value);
        editor.commit();
    }
    private String getValue(Context context, String key) {
        SharedPreferences pref=context.getSharedPreferences(CACHE_DB_NAME,Context.MODE_PRIVATE);
        return pref.getString(key,null);
    }

    public void addString(Context context, String key, String value) {
        addValue(context,key, value);
    }

    public String getString(Context context, String key) {
        return getValue(context, key);
    }

    public String getString(Context context, String key, String defaultValue) {
        String value= getValue(context, key);
        return value == null ? defaultValue : value;
    }

    public void addInteger(Context context, String key, int value) {
        addValue(context,key, String.valueOf(value));
    }

    public int getInteger(Context context, String key) {
        String value=getValue(context, key);
        return value !=null ? Integer.valueOf(value) : -1 ;
    }

    public int getInteger(Context context, String key, int defaultValue) {
        String value=getValue(context, key);
        return value !=null ? Integer.valueOf(value) : defaultValue ;
    }

    public void addLong(Context context, String key, long value) {
        addValue(context,key, String.valueOf(value));
    }

    public long getLong(Context context, String key) {
        String value=getValue(context, key);
        return value !=null ? Long.valueOf(value) : -1L ;
    }

    public long getLong(Context context, String key, long defaultValue) {
        String value=getValue(context, key);
        return value !=null ? Long.valueOf(value) : defaultValue ;
    }

    public void addDouble(Context context, String key, double value) {
        addValue(context,key, String.valueOf(value));
    }

    public double getDouble(Context context, String key) {
        String value=getValue(context, key);
        return value !=null ? Double.valueOf(value) : -1.0 ;
    }

    public double getDouble(Context context, String key, long defaultValue) {
        String value=getValue(context, key);
        return value !=null ? Double.valueOf(value) : defaultValue ;
    }

    public void addJSONObject(Context context, String key, JSONObject jsonObject) {
        addValue(context,key, jsonObject.toString());
    }

    public JSONObject getJSONObject(Context context, String key) {
        String value=getValue(context, key);
        JSONObject jsonObject=null;
        try {
            jsonObject = new JSONObject(value);
        }
        catch(Exception ex) {
            Log.e(AppConstants.LOG_TAG,"Exception while fetching the value for "+key,ex);
        }
        return jsonObject;
    }

    public void addJSONArray(Context context, String key, JSONObject jsonArray) {
        addValue(context,key, jsonArray.toString());
    }

    public JSONArray getJSONArray(Context context, String key) {
        String value=getValue(context, key);
        JSONArray jsonArray=null;
        try {
            jsonArray = new JSONArray(value);
        }
        catch(Exception ex) {
            Log.e(AppConstants.LOG_TAG,"Exception while fetching the value for "+key,ex);
        }
        return jsonArray;
    }
}
